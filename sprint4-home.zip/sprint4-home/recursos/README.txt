La tipografia és "Space Grotesk" de Google.
S'haurà de maquetar en BootStrap en la versió 5.3.8 i icones de BootStrap.
Sempre que pugues hauràs d'utilitzar elements predefinits de BootStrap.  Però si no ho aconsegueixes millor maquetat a mà i que quede igual que no sense maquetar (implicarà una penalització però si no ho trobeu pot ser que és perquè siga maquetat a mà).   
S'haurà d'aconseguir la maquetació pareguda als dissenys presentats.  Qualsevol desviació implicarà una penalització.
El menú superior estarà falcat dalt de tot sempre que es faça un scroll.
Allò que siga un enllaç s'haura de representar com un enllaç.   Els enllaços de les xarxes socials han d'anar a la home d'aquella xarxa social.
Fixeu-se bé en les alineacions de tots els elements en els diversos tamanys i la distrució dels mateixos.  Així mateix com els colors de la tipografia de la lletra i els colors de fons (hi ha llocs que són gris claret, altre blau claret, altres banc ...)
Els colors del fons del body, del fons del banner OFERTA LIMITADA i el color dels fons del text "OFERTA LIMITADA" són colors personlitzats que no té BootStrap.


Les icones són de BootStrap i són les següent:
==============================
Menú superior
==============================
Logo -->     lightbulb-fill
cercar -->   search
carret -->   cart-fill
persona (menú superior) -->  person

==============================
Banda "comprar per categoria"
==============================
fletxa dreta --> arrow-right


==============================
Banda "oferta limitada"
==============================
rellotge --> clock-fill

==============================
Banda "Tendències actuals"
==============================
fletxa dreta --> arrow-right
fletxa esquerra --> arrow-left
cor             --> heart
estrela         --> star-fill

============================================================
Banda "enviament gratuït, pagament segur, suport"
============================================================
camionet --> truck
pagament segur --> shield-lock-fill
suport 24/7 --> headset

============================
Footer - xarxes socials
============================
facebook --> facebook
linkedin --> linkedin
instagram --> instagram


