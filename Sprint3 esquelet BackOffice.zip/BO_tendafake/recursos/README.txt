Es tracta de maquetar amb el grid i les indicacions seguides en el document "Com abordar la maquetació des de 0" el que hi ha en les captures de pantalla adjuntes.
En la carpeta recursos teniu les captures de pantalla així com les imatges necessàries.


=================================
Tipografia: 
=================================
Roboto de Google

=================================
Icones:
=================================
Tipografia FontAweSome

eixir: arrow right from bracket
atributs: paper clip
carret: cart shopping 
clients: person
configuracions: sliders
comandes: pento square
estadístiques: chart line
famílies: list
localitzacions: location dot
ofertes: tag 
productes: city
usuaris: user



cercar: magnifying glass
netejar: xmark


=================================
Textos:
=================================

Llistat d'usuaris

    Atributs
    Carrets
    Clients
    Configuracions
    Comandes
    Estadístiques
    Famílies
    Localitzacions
    Ofertes
    Productes
    Usuaris

Nom
Cognoms
Dni
Email

Cercar
Netejar

Manolo Garibolo


=================================
AVISOS:
=================================
1) Reaprofiteu estils per a després:
Si ja poseu que els inputs tots tinguen eixe estil predeterminat després només soltant un input ja tindrà el format que cal en qualsevol lloc (finestra d'alta, edició, cerca, ...).
El mateix amb els botons, la taula ... i a l'hora d'integrar-ho tot serà més senzill.
2) si una cosa que ha de tindre un ample determinat perquè sempre és el mateix, se li pot posar.
Exemple: hi ha element d'una columna que tenen diversos tamanys i volem que sempre tinga el seu contenidor el seu tamany i sempre centrar-ho al mig, a un costat o a l'altre.
3)S'haurà de tindre presents els criteris d'usabilitat
4)En passar per damunt del menú lateral canvia el fons i la lletra és remarca més
5)En passar per damunt d'un botó la lletra es remarca més
6)Fixeu-se en els inputs el format que tenen.  He posat un text dins del camp del nom com a exemple per a què vegueu si li posem contingut com ha de quedar
El cercador després mostrarà contingut en prémer el botó "Cercar" i mostrarà la informació que complisca els filtres en una taula que estarà baix.
7)Tot allò que siga html haurà d'estar correcte: allò que és candidat a ser un enllaç serà un enllaç, els camps han de ser del tipus de la informació que contindrà (text, data, ...), ...



