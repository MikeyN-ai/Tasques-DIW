
Totes les icones són de BootStrap.


Icono del logo: bi bi-lightbulb

Les icones del botó de cercador són:

bi bi-funnel
bi bi-trash


Icona aplicar: bi bi-check-circle
Icona crear: bi bi bi-plus-circle


Les icones del menú lateral són:

bi bi-paperclip 
bi bi-cart-fill
bi bi-person-standing
bi bi-sliders
bi bi-bag
bi bi-bar-chart
bi bi-folder
bi bi-geo-alt
bi bi-tag
bi bi-box-seam
bi bi-person
bi bi-box-arrow-right


A tindre en consideració:
s'hauran d'aplicar els criteris d'usabilitat.

En escriptori només fa scroll el contingut de la taula.  El menú superior i lateral estan sempre en la mateixa posició.

En mòbil quan ix el menú desplegable es lleva l'scroll i quan desapreix torna a eixir l'scroll per poder desplaçar-se i veure el contingut de la taula fins al final.

Per a la maquetació haureu de començar des de 0 amb BootStrap.   Per a fer la taula en responsive podeu aprofitar els media-query de mòbil que tenieu en els estils en el disseny de l'sprint anterior.

!!!! RECORDEU QUE TOTS ELS CAMPS DELS FILTRES HAN DE TINDRE EL TEXT QUE FIGURA EN LA CAPTURA 1600px.png QUAN NO TENEN CAP INFORMACIÓ !!!!!!!!!

La majoria de coses eixiràn de components o elements BootStrap ja predefinits.   Però en cas de no existir s'haurà de personalitzar els estils.   Sobretot els colors, perquè molts d'ells no estsan en Bootstrap ja predeterminats.


